from django.urls import path
from . import views

urlpatterns = [
    path('output/',views.output),
    path('',views.frontpage),
]