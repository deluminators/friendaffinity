from django.shortcuts import render
from django .http import HttpResponse


# Create your views here.
def company_details(request):
    return render(request, 'company_details.html')
def output_company(request):
    return render(request, 'output_company.html')
def candidate_details(request):
    return render(request, 'candidate_details.html')


def frontpage(request):
    return render(request,'frontpage.html')


def employee_details(request):

    company_name = request.GET.get('company_name', 'default')
    address = request.GET.get('address', 'default')
    email = request.GET.get('email', 'default')
    link = request.GET.get('link', 'default')

    params = {
        'company_name': company_name,
        'address': address,
        'email': email,
        'link': link,

    }
    return render(request, 'employee_details.html', params)

def output(request):
    full_name = request.GET.get('full_name', 'default')
    DOB = request.GET.get('DOB', 'default')
    Gender = request.GET.get('Gender', 'default')
    link1 = request.GET.get('link1', 'default')
    link2 = request.GET.get('link2', 'default')
    link3 = request.GET.get('link3', 'default')
    params = {
        'full_name': full_name,
        'DOB': DOB,
        'Gender': Gender,
        'link1': link1,
        'link2': link2,
        'link3': link3,
    }
    return render(request, 'output.html', params)